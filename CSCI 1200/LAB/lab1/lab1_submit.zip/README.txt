LAB 1: GETTING STARTED


NAME:  < insert name >



COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to in the first lecture & first
lab (classmates, graduate TAs, undergraduate programming mentors, ALAC
tutors, upperclassmen, students/instructor via LMS, etc.), and all of
the resources (books, online reference material, etc.) you consulted
in completing this assignment. 


< insert collaborators / resources >




NAMES OF YOUR TA & MENTORS

Who is your graduate lab TA? 

<insert name>

Who are the undergraduate programming mentors assigned to your lab?

<insert names>














