HOMEWORK 10: MULTIPLE INHERITANCE & EXCEPTIONS


NAME:  < Yunhe Wang >



COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Prof Thompson;
  Yihao Zhu;
  John Andrews;
  www.cplusplus.com;
 >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF 12 OF HOURS SPENT ON THIS ASSIGNMENT:  < insert 12 hours >



MISC. COMMENTS TO GRADER:  
Optional, please be concise!






