EXTRA CREDIT HOMEWORK: DEBUGGING

NAME:  < Yunhe Wang >



ESTIMATE OF 10 OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



GOAL:
< A bright young coder named Lee
Wished to loop while i was 3
But when writing the =
He forgot its sequel
And thus looped infinitely >



COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(TAs, ALAC tutors, upperclassmen, students/instructor via LMS,
etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< www.cplusplus.com >

Remember: All finding and fixing bugs for this assignment must be
done on your own, as described in "Academic Integrity for Homework"
handout.



EXTRA CREDIT:
List any bugs you found that did not or should not affect the normal execution
of the program. (These should also go in your writeup.)

vector_sum() function. It don't need to pass by reference if the main code doesn't required to change the contents of vectors;
triangle.h line40, it is better to use "const" before std::string


MISC. COMMENTS TO GRADER:
Optional, please be concise!
